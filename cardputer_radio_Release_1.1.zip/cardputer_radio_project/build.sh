#!/bin/bash

echo "========================================="
echo "CardPuter Radio - Building Binary"
echo "========================================="
echo ""

# Check if PlatformIO is installed
if ! command -v pio &> /dev/null
then
    echo "ERROR: PlatformIO is not installed!"
    echo ""
    echo "Please install PlatformIO first:"
    echo "  pip install platformio"
    echo ""
    echo "Or use the PlatformIO IDE extension for VS Code"
    exit 1
fi

echo "Building project..."
pio run

if [ $? -eq 0 ]; then
    echo ""
    echo "========================================="
    echo "✓ Build successful!"
    echo "========================================="
    echo ""
    echo "Binary files created:"
    echo "  - .pio/build/m5stack-cardputer/firmware.bin"
    echo "  - .pio/build/m5stack-cardputer/cardputer_radio.bin"
    echo ""
    echo "To upload to CardPuter via USB:"
    echo "  pio run --target upload"
    echo ""
    echo "For M5Launcher, copy this file to SD card:"
    echo "  .pio/build/m5stack-cardputer/cardputer_radio.bin"
    echo "  → SD:/launcher/apps/"
    echo ""
else
    echo ""
    echo "========================================="
    echo "✗ Build failed!"
    echo "========================================="
    echo ""
    echo "Check the error messages above"
    exit 1
fi
