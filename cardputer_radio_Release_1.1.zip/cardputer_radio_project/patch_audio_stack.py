# Pre-build patch: enlarge the ESP32-audioI2S internal audio task stack.
#
# WHY THIS EXISTS
# ---------------
# The library runs decode + I2S output in its OWN FreeRTOS task, created in
# Audio.cpp as:
#
#     xTaskCreate(&Audio::taskWrapper, "PeriodicTask", 3300, this, 4, ...);
#
# 3300 bytes is not enough. Confirmed by an addr2line decode of a real panic
# after 7h49m of playback:
#
#     Stack canary watchpoint triggered (PeriodicTask)
#       Audio::IIR_filterChain0()   <- float-heavy filter math
#       Audio::playChunk()
#       Audio::sendBytes()
#       Audio::playAudioData()
#       Audio::performAudioTask()   <- the "PeriodicTask" entry point
#
# It was preceded by a corrupt frame that made the decoder resync onto a bogus
# header (44100/stereo -> 11025/mono) and recalculate its IIR coefficients.
# That deeper float path overflowed the 3300-byte stack.
#
# startAudioTask()/stopAudioTask() are PRIVATE in Audio.h, so the sketch cannot
# re-drive this work on its own generously-sized task. Patching the constant is
# the only route that does not require forking the library.
#
# Idempotent: re-running finds nothing to change.
Import("env")
import os, re

NEW_STACK = 8192
LIBDIR = os.path.join(env.subst("$PROJECT_LIBDEPS_DIR"), env.subst("$PIOENV"))
target = os.path.join(LIBDIR, "ESP32-audioI2S", "src", "Audio.cpp")

if not os.path.isfile(target):
    print("[audio-stack] Audio.cpp not found yet (first run?) - skipping")
else:
    src = open(target, encoding="utf-8", errors="ignore").read()
    m = re.search(r'("PeriodicTask"\s*,\s*)(\d+)', src)
    if not m:
        print("[audio-stack] WARNING: task creation line not found - library "
              "changed? Stack NOT patched.")
    elif int(m.group(2)) >= NEW_STACK:
        print("[audio-stack] already %s bytes - ok" % m.group(2))
    else:
        old = int(m.group(2))
        src = src[:m.start(2)] + str(NEW_STACK) + src[m.end(2):]
        open(target, "w", encoding="utf-8").write(src)
        print("[audio-stack] PeriodicTask stack %d -> %d bytes" % (old, NEW_STACK))
