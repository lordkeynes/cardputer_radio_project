Import("env")
import os
import shutil

def rename_binary(source, target, env):
    firmware_path = str(target[0])
    firmware_dir = os.path.dirname(firmware_path)
    new_name = os.path.join(firmware_dir, "cardputer_radio.bin")
    
    # Copy the firmware to the new name
    if os.path.exists(firmware_path):
        shutil.copy(firmware_path, new_name)
        print(f"Created M5Launcher compatible binary: {new_name}")

env.AddPostAction("$BUILD_DIR/${PROGNAME}.bin", rename_binary)
