// ============================================================
//  CARDPUTER RADIO
//
//  IMPORTANT HARDWARE NOTE:
//  The Cardputer-Adv uses the Stamp-S3A / ESP32-S3FN8: 8MB embedded
//  flash and *** NO PSRAM ***. The entire memory budget is ~320KB of
//  internal SRAM, most of which WiFi claims. Every KB matters.
//
//  Consequences, learned the hard way:
//   - There is no off-screen framebuffer. A 240x135x8bpp sprite costs
//     32KB, which is better spent as audio buffer. We draw directly and
//     avoid flicker by painting text over its own background color.
//   - The decoder's stream buffer is the ONLY cushion against network
//     jitter, and it lives in internal RAM. It is sized as large as we
//     can afford (see AUDIO_BUF_BYTES).
//   - TLS handshakes need ~40KB free heap. They will usually fail here,
//     so the recorder falls back to plain HTTP.
// ============================================================
#define RELEASE_NAME "Release 1.1"
#define FW_VERSION   "r42"

#include <M5Cardputer.h>
#include <WiFi.h>
#include <Preferences.h>
#include <SPI.h>
#include <SD.h>
#include <FS.h>
#include <algorithm>
#include <time.h>
#include "Audio.h"

// ============================================================
//  USER SETTINGS
// ============================================================
#define DIM_TIMEOUT_MS   20000   // idle ms before the screen dims
#define OFF_TIMEOUT_MS   60000   // idle ms before the screen blanks
#define BRIGHT_FULL      100     // normal brightness (0-255)
#define BRIGHT_DIM       12      // dimmed brightness
#define UI_REFRESH_MS    150     // marquee tick
#define UI_IDLE_MS       500     // refresh when nothing is scrolling

// Stream buffer -- the ONLY defence against network/server jitter.
//
// This is the whole story for dropouts: bytes that arrive late are covered by
// whatever is already buffered, and nothing else. At 128kbps, 16KB ~= 1s.
//
//   20KB -> ~1.2s   (what the library reported as inputBufferSize 18431)
//   48KB -> ~2.9s
//
// BACK TO 20KB. 48KB cost ~28KB of heap and pushed min-free to 14k and the
// largest contiguous block to 9k -- below the recorder's own 10k guard, i.e.
// recording would have been refused. And the deep buffer was never the fix:
// telemetry showed buf=100% and gap in single digits at 20KB. It was insurance
// against a network problem the data never showed.
//
// It lives in internal SRAM (no PSRAM on this board), so every KB here is a KB
// off the heap. Watch 'min' in the D overlay after changing this: if it falls
// below ~25k, come back down. A crash is worse than a dropout.
#define AUDIO_BUF_BYTES  (20 * 1024)

// CardPuter SD SPI pins. MUST be set explicitly: the ESP32-S3 default SPI
// MOSI is GPIO11, which on the Adv is the keyboard IRQ line. Letting SPI
// take its defaults silently kills the keyboard.
#define SD_SCK   40
#define SD_MISO  39
#define SD_MOSI  14
#define SD_CS    12

// ============================================================
//  THEME
// ============================================================
#define C_BG      0x0000
#define C_GREEN   0x07E0
#define C_DGREEN  0x02E0
#define C_GREY    0x8410
#define C_RED     0xF800
#define C_AMBER   0xFD20

Preferences preferences;
Audio audio;
auto& disp = M5Cardputer.Display;

// The SD card gets its OWN SPI controller.
//
// "SPI2 vs SPI3" is not a wiring question -- the ESP32-S3 GPIO matrix routes
// any peripheral to any pin, so the card keeps its exact physical pins and we
// simply drive them from a different internal controller. This matters because
// the Arduino global `SPI` object is FSPI (SPI2_HOST), which is the same
// controller M5GFX uses for the display. Two drivers reconfiguring one
// peripheral behind each other's backs is what corrupted our SD writes
// (fail code -108). On SPI3 they cannot collide at all.
SPIClass sdSPI(HSPI);   // HSPI == SPI3_HOST on the ESP32-S3

struct Station {
  String name;
  String url;
};
std::vector<Station> stations;

// Built-in station list. Used when there is no SD card or no station_list.txt,
// so the radio is fully usable with no card at all. Keep station_list.txt on
// the SD card in sync with this if you want identical behaviour either way.
//
// Query-string tokens (?uuid=, ?playerid=) are deliberately stripped: they are
// listener-analytics identifiers rather than credentials, and a token that
// expires would silently kill a station months from now.
const Station defaultStations[] = {
  {"WYSO 91.3 NPR",             "https://playerservices.streamtheworld.com/api/livestream-redirect/WYSOFM.mp3"},
  {"NPR News",                  "https://npr-ice.streamguys1.com/live.mp3"},
  {"KEXP 90.3 Seattle",         "https://kexp-mp3-128.streamguys1.com/kexp128.mp3"},
  {"WFMU 91.1 Freeform",        "http://stream0.wfmu.org/freeform-128k"},
  {"WWOZ 90.7 New Orleans",     "https://wwoz-sc.streamguys1.com/wwoz-hi.mp3"},
  {"KCRW 89.9 Santa Monica",    "https://streams.kcrw.com/kcrw_mp3"},
  {"KALW 91.7 San Francisco",   "https://kalw-live.streamguys1.com/kalw.aac"},
  {"WFPK 91.9 Louisville",      "https://lpm.streamguys1.com/wfpk-popup.aac"},
  {"WTJU 91.1 Charlottesville", "https://streams.wtju.net/wtju-live"}
};

// Derived, not hardcoded. loadDefaultStations() used to loop `i < 3`, which
// would have silently dropped any station added past the third.
const int numDefaultStations = sizeof(defaultStations) / sizeof(defaultStations[0]);

int      currentStation = 0;
bool     isPlaying      = false;
uint8_t  volume         = 10;   // 0-21
// Fixed buffer, deliberately NOT a String. This is rewritten on every ICY
// metadata update and read on every frame; a String here churns the heap.
char     streamTitle[160] = {0};
uint16_t streamTitleLen   = 0;
int      marqueeOffset    = 0;

// Many stations send NO ICY metadata at all. Without these, the status line
// sat there claiming "buffering..." forever while the stream played perfectly.
char     icyStation[64]   = {0};   // station name, per the server
char     icyDesc[96]      = {0};   // station description

uint32_t lastActivity   = 0;
uint8_t  brightness     = BRIGHT_FULL;
uint32_t lastDraw       = 0;

// --- Screen mode (drives when we clear the screen) ---
enum Screen { SCR_MAIN, SCR_PICKER };
Screen currentScreen = SCR_MAIN;
Screen lastScreen    = SCR_PICKER;   // force a chrome draw on first pass

// --- Audio task ---
TaskHandle_t      audioTaskHandle = NULL;
SemaphoreHandle_t audioMutex      = NULL;

// --- SPI bus mutex ---
// The display AND the SD card sit on SPI, and they are driven from DIFFERENT
// tasks: the UI draws from the Arduino loop (core 1) while the recorder writes
// to the card (core 0). With no lock, those transactions interleave and
// corrupt each other -- which shows up as a short f.write() and a recording
// that dies. Every display draw and every SD access must hold this.
SemaphoreHandle_t spiMutex = NULL;
#define SPI_LOCK()    xSemaphoreTake(spiMutex, portMAX_DELAY)
#define SPI_UNLOCK()  xSemaphoreGive(spiMutex)

// --- Stream health watchdog ---
// A stream that has been up for hours can quietly degrade: the buffer drains
// and never refills. Rather than sit there stuttering, notice and re-dial.
uint32_t lowBufSince    = 0;   // when the buffer first went critically low
uint32_t degradedSince  = 0;   // when the buffer first went chronically low
uint32_t lastDialMs     = 0;   // when we last (re)connected -- grace window
bool     metricsPending = false;  // clear timing watermarks once connect settles

// --- Battery smoothing ---
// The raw reading is an ADC voltage estimate, and WiFi transmit bursts sag the
// rail enough to swing it several points. Displaying it directly makes the
// percentage flicker back and forth. We low-pass it, then only move the shown
// value when the smoothed figure has clearly moved (hysteresis) -- so it steps
// cleanly instead of oscillating.
float   battAvg     = -1.0f;   // running average, -1 = not seeded yet
int     battShown   = -1;      // what is actually on screen
uint32_t lastBattMs = 0;
uint32_t streamRedials  = 0;

// Settings persistence (volume + last station). Writes are DEBOUNCED: volume
// arrives in bursts of keypresses and flash has limited write cycles, so we
// mark dirty and flush a few seconds after the last change, not per press.
// --- Stream format guard ---
// A corrupt frame can fool the decoder into resyncing onto a BOGUS header and
// reconfiguring itself mid-stream (observed: a 44100/stereo/128k stream
// suddenly reported as 11025/mono/40k, followed by filter recalculation and a
// stack-canary panic seconds later). A live radio station never legitimately
// changes format, so any change is corruption -> re-dial instead of riding it.
volatile uint32_t streamRateSeen = 0;   // first sample rate after connect
volatile bool     formatChanged  = false;
bool     wasPlaying    = false;   // persisted, for auto-resume after a crash
bool     settingsDirty  = false;
uint32_t settingsDirtyMs = 0;
uint32_t lastWifiPoke   = 0;

// --- Diagnostics (hidden: Ctrl+D) ---
// Gates BOTH the on-screen overlay and all serial telemetry. A release build
// stays quiet; flip this and the device tells you everything.
bool     showDiag    = false;
bool     soakLog     = false;   // Ctrl+L: serial telemetry that ignores screen state

// Rolling worst-case trackers for an UNATTENDED run. Unlike the overlay's
// high-water marks (which you reset by eye), these snapshot-and-clear every
// log line, so each line describes only the last interval -- you can see WHEN
// a hitch happened, not just that one did at some point.
uint32_t gapIntervalMax = 0;
uint32_t bufIntervalMin = 100;
uint32_t underrunEvents = 0;    // times bufPct crossed below 25% this interval
uint32_t bufPct      = 0;
uint32_t bufLowCount = 0;
uint32_t lastBufLog  = 0;

// Stall detection. If the buffer is full but audio still glitches, the
// decoder is being starved of CPU, not of data. These find the culprit:
//   gap = worst delay between successive audio.loop() calls
//   dec = worst time spent INSIDE audio.loop()
//   drw = worst time spent drawing the UI
// A gap far larger than the I2S DMA cushion is what you hear.
volatile uint32_t gapMaxUs = 0;
volatile uint32_t decMaxUs = 0;
volatile uint32_t drwMaxUs = 0;

// --- Station picker ---
bool pickerOpen = false;
int  pickerSel  = 0;
int  pickerTop  = 0;
#define PICKER_ROWS 7

// --- Saved WiFi networks ---
#define MAX_WIFI 5
struct WifiCred {
  String ssid;
  String pass;
};
std::vector<WifiCred> wifiCreds;

// --- Stream recorder ---
#define REC_MAX_RECONNECTS 50
volatile uint32_t recReconnects = 0;
volatile uint32_t sdRecoveries  = 0;
volatile bool     recActive   = false;
volatile bool     recStopReq  = false;
volatile uint32_t recBytes    = 0;
volatile int      recFailCode = 0;
uint32_t          recStartMs  = 0;
uint32_t          recFailMs   = 0;
String            recUrl, recBase;
struct tm         recStartTm;
bool              recTimeValid = false;
TaskHandle_t      recTaskHandle = NULL;

// Forward declarations
void loadStationsFromSD();
void loadDefaultStations();
void setupWiFi();
void setupWiFi(bool cancellable);
void connectWiFi();
void loadSettings();
void saveSettingsDebounced();
void flushSettings();
void loadWifiCreds();
void saveWifiCred(const String& ssid, const String& pass);
bool tryConnect(const String& ssid, const String& pass, int waitSecs);
String getTextInput(String prompt, bool mask = false);
void drawUI();
void drawMainChrome();
void drawMain();
void drawPicker();
void openPicker();
void handlePickerKeys(Keyboard_Class::KeysState& status);
void drawBattery(int x, int y);
void drawClock(int rightX, int y);
static void formatUptime(char* out, size_t n);
void drawVolumeBar(int x, int y);
void drawWifiBars(int x, int y);
void togglePlayPause();
void startPlayback();
void stopPlayback();
void nextStation();
void previousStation();
void increaseVolume();
void decreaseVolume();
void wakeScreen();
void updateDimming();
void startRecording();
void requestStopRecording();
void recorderTask(void* arg);
void audioTask(void* arg);

// Print text padded/truncated to an exact width, so leftovers from a longer
// previous string get painted over. Allocation-free ON PURPOSE: this runs on
// every field of every frame, several times a second, for hours. The old
// String-returning version was the main source of heap fragmentation --
// free heap stayed plausible while the largest contiguous block collapsed.
// Split a station name across two 19-char lines, breaking on a space rather
// than mid-word. 19 chars is what fits at text size 2 (19 * 12px = 228px).
static void wrapName(const char* name, char* l1, size_t n1, char* l2, size_t n2) {
  size_t len = strlen(name);
  l2[0] = '\0';

  if (len <= 19) {
    snprintf(l1, n1, "%s", name);
    return;
  }

  int brk = -1;
  for (int i = 0; i < 19 && name[i]; i++) {
    if (name[i] == ' ') brk = i;
  }
  if (brk < 0) brk = 19;              // one long word: hard split

  int copy = brk;
  if (copy > (int)n1 - 1) copy = n1 - 1;
  memcpy(l1, name, copy);
  l1[copy] = '\0';

  const char* rest = name + brk;
  while (*rest == ' ') rest++;
  snprintf(l2, n2, "%.19s", rest);
}

static void printPad(int x, int y, const char* txt, int width) {
  char buf[64];
  if (width > 63) width = 63;
  snprintf(buf, sizeof(buf), "%-*.*s", width, width, txt);
  disp.setCursor(x, y);
  disp.print(buf);
}

// ============================================================
//  ESP32-audioI2S callbacks
// ============================================================
void audio_showstreamtitle(const char* info) {
  strncpy(streamTitle, info, sizeof(streamTitle) - 1);
  streamTitle[sizeof(streamTitle) - 1] = '\0';
  streamTitleLen = strlen(streamTitle);
  marqueeOffset = 0;
  if (showDiag) Serial.printf("Stream title: %s\n", info);
}

void audio_showstation(const char* info) {
  strncpy(icyStation, info, sizeof(icyStation) - 1);
  icyStation[sizeof(icyStation) - 1] = '\0';
  if (showDiag) Serial.printf("ICY station: %s\n", info);
}

void audio_icydescription(const char* info) {
  strncpy(icyDesc, info, sizeof(icyDesc) - 1);
  icyDesc[sizeof(icyDesc) - 1] = '\0';
}

void audio_info(const char* info) {
  // Always parse, even when not logging: this is the format guard.
  const char* sr = strstr(info, "SampleRate:");
  if (sr) {
    uint32_t rate = (uint32_t)atoi(sr + 11);
    if (rate > 0) {
      if (streamRateSeen == 0)        streamRateSeen = rate;
      else if (rate != streamRateSeen) formatChanged = true;
    }
  }

  // The library emits a line for almost everything it does. Useful when
  // hunting a stream problem, pure noise otherwise.
  if (showDiag) Serial.printf("audio: %s\n", info);
}

// ============================================================
//  SETUP
// ============================================================
void setup() {
  auto cfg = M5.config();
  M5Cardputer.begin(cfg, true);   // true = enable keyboard

  Serial.begin(115200);
  Serial.println("\n\n=== CardPuter Radio " RELEASE_NAME " (build " FW_VERSION ") ===");
  Serial.printf("heap at boot: %u\n", (unsigned)ESP.getFreeHeap());
  if (!psramFound()) Serial.println("No PSRAM (expected on Stamp-S3A)");

  spiMutex = xSemaphoreCreateMutex();

  disp.setRotation(1);
  disp.setBrightness(BRIGHT_FULL);
  disp.fillScreen(C_BG);

  // Splash
  disp.setTextColor(C_GREEN, C_BG);
  disp.setTextSize(2);
  disp.setCursor(24, 45);
  disp.println("CARDPUTER");
  disp.setCursor(60, 68);
  disp.println("RADIO");
  disp.setTextSize(1);
  disp.setTextColor(C_GREY, C_BG);
  disp.setCursor(72, 90);
  disp.println(RELEASE_NAME);
  disp.setCursor(102, 102);
  disp.println(FW_VERSION);      // internal build, for bug reports
  delay(800);

  disp.setCursor(10, 110);
  disp.println("Loading stations...");

  // Note: we deliberately do NOT touch the global `SPI` object. Leaving it
  // un-begun also keeps it off GPIO11, which is the Adv's keyboard IRQ line
  // (the bug that cost us r1-r3).
  sdSPI.begin(SD_SCK, SD_MISO, SD_MOSI, SD_CS);
  if (!SD.begin(SD_CS, sdSPI, 10000000)) {
    Serial.println("SD: begin failed on SPI3");
  } else {
    Serial.println("SD: mounted on SPI3 (own controller)");
  }
  loadStationsFromSD();
  if (stations.size() == 0) loadDefaultStations();
  Serial.printf("Stations loaded: %d\n", (int)stations.size());

  loadSettings();   // volume + last station (clamped to the loaded list)

  connectWiFi();

  // Clock for recording filenames (US Eastern, auto DST)
  configTzTime("EST5EDT,M3.2.0,M11.1.0", "pool.ntp.org", "time.nist.gov");

  // Speaker init also brings up the ES8311 codec
  auto spk_cfg = M5Cardputer.Speaker.config();
  M5Cardputer.Speaker.config(spk_cfg);
  M5Cardputer.Speaker.begin();

  audio.setPinout(spk_cfg.pin_bck, spk_cfg.pin_ws, spk_cfg.pin_data_out);

  // The whole anti-stutter story, in one line. With no PSRAM this buffer
  // lives in internal SRAM, so it is the RAM we freed by dropping the
  // 32KB display sprite. Must be set BEFORE connecttohost().
  audio.setBufsize(AUDIO_BUF_BYTES, 0);
  Serial.printf("audio buffer: %u bytes, heap now %u\n",
                (unsigned)AUDIO_BUF_BYTES, (unsigned)ESP.getFreeHeap());

  audio.setVolume(volume);

  // Feed the decoder from its own high-priority task on core 1 so that
  // display writes and key handling can never starve it.
  audioMutex = xSemaphoreCreateMutex();
  // Priority 10: well above the Arduino loop (1), still below the WiFi
  // driver tasks (18+). The decoder must win every scheduling contest
  // against the UI, or you hear it.
  xTaskCreatePinnedToCore(audioTask, "audio", 14336, NULL, 10, &audioTaskHandle, 1);

  // Auto-resume. The one crash this firmware has produced was self-recovering
  // (it rebooted cleanly), but it came back STOPPED -- useless if the radio is
  // unattended. If we were playing when power was lost, start again.
  if (wasPlaying && WiFi.isConnected() && stations.size() > 0) {
    Serial.println("Auto-resuming previous station");
    startPlayback();
  }

  lastActivity = millis();
  disp.fillScreen(C_BG);
  drawUI();
}

// ============================================================
//  MAIN LOOP
// ============================================================
void loop() {
  M5Cardputer.update();
  // audio.loop() runs in audioTask on core 1 -- see setup()

  if (M5Cardputer.Keyboard.isChange() && M5Cardputer.Keyboard.isPressed()) {
    // Any keypress on a dimmed OR blanked screen only wakes it -- it never
    // fires an action. Waking must be safe: glancing at the screen should
    // not, say, kill an in-progress recording.
    bool wasAsleep = (brightness != BRIGHT_FULL);
    wakeScreen();

    if (!wasAsleep) {
      Keyboard_Class::KeysState status = M5Cardputer.Keyboard.keysState();

      // KEY TRACE: prints exactly what the keyboard reported. Fires in debug
      // mode, OR whenever any modifier is held -- so you can discover which
      // modifier this keyboard actually reports without needing the overlay
      // (which itself requires a working modifier: chicken and egg).
      if (showDiag || status.ctrl || status.fn || status.opt || status.alt) {
        char chars[16] = {0};
        size_t k = 0;
        for (char ch : status.word) {
          if (k < sizeof(chars) - 1) chars[k++] = ch;
        }
        Serial.printf("KEY n=%u '%s' hex=", (unsigned)status.word.size(), chars);
        for (char ch : status.word) Serial.printf("%02X ", (uint8_t)ch);
        Serial.printf("| enter=%d del=%d shift=%d fn=%d ctrl=%d alt=%d opt=%d\n",
                      status.enter, status.del, status.shift, status.fn,
                      status.ctrl, status.alt, status.opt);
      }

      if (pickerOpen) {
        handlePickerKeys(status);
      } else {
        bool isSpace = (status.word.size() == 1 && status.word[0] == ' ');
        char key = (status.word.size() == 1) ? status.word[0] : 0;

        // ---- Hidden developer combos, checked FIRST ----
        //
        // These MUST come before the plain-key chain. The old code put Ctrl+L
        // *after* the plain 'l' -> openPicker() branch, so the picker always
        // shadowed it and Ctrl+L did nothing. Modifier combos are unambiguous;
        // test them up front.
        //
        // The Cardputer has no dedicated Ctrl key -- the modifiers are
        // Fn (bottom-left), Shift, Opt, and Alt. Rather than guess which one
        // the library maps to `ctrl`, we accept ANY of fn/ctrl/opt/alt as the
        // developer modifier. Serial confirms which flag actually fired.
        bool devMod = status.ctrl || status.fn || status.opt || status.alt;

        if (devMod && (key == 'd' || key == 'D')) {
          // Ctrl+D is the ONE combo confirmed working on this keyboard, so it
          // cycles through all three states rather than relying on a second
          // combo (Ctrl+G) that this keyboard doesn't deliver:
          //   off -> overlay only -> overlay + soak log -> off
          if (!showDiag && !soakLog) {
            showDiag = true;  soakLog = false;
          } else if (showDiag && !soakLog) {
            showDiag = true;  soakLog = true;
          } else {
            showDiag = false; soakLog = false;
          }
          bufLowCount = 0;
          gapMaxUs = decMaxUs = drwMaxUs = 0;
          Serial.printf("DIAG overlay=%d soaklog=%d\n", showDiag, soakLog);
          SPI_LOCK();
          disp.startWrite();
          disp.fillScreen(C_BG);
          disp.endWrite();
          disp.waitDMA();
          SPI_UNLOCK();
          lastScreen = SCR_PICKER;   // force chrome redraw
        }
        // ---- Normal controls ----
        else if (status.enter || isSpace) {
          togglePlayPause();
        } else if (key) {
          if      (key == 'n' || key == 'N') nextStation();
          else if (key == 'p' || key == 'P') previousStation();
          else if (key == '+' || key == '=') increaseVolume();
          else if (key == '-' || key == '_') decreaseVolume();
          else if (key == 'r' || key == 'R') { if (isPlaying) startPlayback(); }
          else if (key == 'l' || key == 'L') openPicker();
          else if (key == 's' || key == 'S') {
            if (recActive) requestStopRecording();
            else           startRecording();
          }
          // 'W' -- add a WiFi network on demand. Lets you join a new network
          // without a reboot (e.g. booted offline somewhere new). setupWiFi()
          // is a blocking prompt with its own screen; stop recording first so
          // its SD writes don't fight the prompt, then restore the UI.
          else if (key == 'w' || key == 'W') {
            if (recActive) { requestStopRecording(); delay(300); }
            setupWiFi(true);             // cancellable on-demand prompt
            if (WiFi.isConnected()) WiFi.setSleep(false);
            lastScreen = SCR_PICKER;     // force full chrome redraw on return
            disp.fillScreen(C_BG);
          }
        }
      }
    }
    drawUI();
  }

  updateDimming();

  // Stream format guard. See the note by streamRateSeen: a mid-stream format
  // change means the decoder has locked onto garbage, which preceded the only
  // crash this firmware has produced. Re-dial rather than keep feeding it.
  if (isPlaying && formatChanged && millis() - lastDialMs > 3000) {
    Serial.printf("STREAM: format changed mid-stream (was %uHz) "
                  "-- corrupt sync, redialling\n", (unsigned)streamRateSeen);
    formatChanged = false;
    streamRedials++;
    startPlayback();
  }

  // Deferred watermark reset after a (re)connect. Waits until well past the
  // blocking connect so the stall it causes is recorded and THEN discarded --
  // the marks describe steady-state playback, not the station change.
  if (metricsPending && millis() - lastDialMs > 3000) {
    gapMaxUs    = 0;
    decMaxUs    = 0;
    bufLowCount = 0;
    metricsPending = false;
  }

  // Flush volume/station 3s after the last change, so a burst of +/- presses
  // is one flash write, not twenty.
  if (settingsDirty && millis() - settingsDirtyMs > 3000) {
    flushSettings();
  }

  // Keep WiFi power-save OFF.
  //
  // We only set this once, at connect. If the link ever drops and silently
  // auto-reconnects, modem sleep comes BACK ON -- and power-save wrecks
  // streaming throughput. That looks exactly like a buffer that slowly starves
  // after hours of uptime. Re-assert it periodically; the call is cheap.
  if (millis() - lastWifiPoke > 30000) {
    lastWifiPoke = millis();
    if (WiFi.isConnected()) {
      WiFi.setSleep(false);
    } else if (!wifiCreds.empty()) {
      // Offline (booted out of range, or link dropped). Try to get back on
      // without blocking playback of anything already buffered. Non-blocking:
      // WiFi.begin returns immediately; we check status on the next poke.
      //
      // ROTATE through the saved networks rather than always trying creds[0]:
      // if you're at a second location, the first saved network is exactly the
      // one that ISN'T here, and pinning to it means never reconnecting.
      static size_t reconnectIdx = 0;
      const WifiCred& c = wifiCreds[reconnectIdx % wifiCreds.size()];
      reconnectIdx++;
      Serial.printf("WiFi: offline, background reconnect try '%s'\n", c.ssid.c_str());
      WiFi.begin(c.ssid.c_str(), c.pass.c_str());
    }
  }

  // Stream watchdog, two-tier. The single 15%/20s rule missed the most common
  // real failure: a stream that DEGRADES without disconnecting. In testing,
  // WFPK's AAC feed dropped from 100% to a 16-41% band and sat there for 18
  // minutes -- audibly rough the whole time -- because it never crossed 15%.
  //
  //   FAST : buffer craters (<15%) for 20s  -> hard failure, re-dial
  //   SLOW : buffer stays chronically low (<45%) for 60s -> degraded, re-dial
  //
  // A healthy stream sits at ~100%, so 45% is comfortably clear of false trips.
  // A freshly re-dialled stream needs time to fill its buffer, during which
  // bufPct is legitimately low. Skip the watchdog for a grace window after any
  // (re)connect, or it would immediately re-trigger and thrash.
  if (isPlaying && millis() - lastDialMs < 15000) {
    lowBufSince   = 0;
    degradedSince = 0;
  } else if (isPlaying) {
    // fast path -- near-empty buffer, connection is basically dead
    if (bufPct < 15) {
      if (lowBufSince == 0) lowBufSince = millis();
      else if (millis() - lowBufSince > 20000) {
        streamRedials++;
        Serial.printf("STREAM: buffer crashed <15%% for 20s (buf=%u%% rssi=%d) "
                      "-- redialling (#%u)\n",
                      (unsigned)bufPct, WiFi.isConnected() ? WiFi.RSSI() : 0,
                      (unsigned)streamRedials);
        startPlayback();
        lowBufSince   = 0;
        degradedSince = 0;
      }
    } else {
      lowBufSince = 0;
    }

    // slow path -- chronically starved but not dead. This is the WFPK case.
    if (bufPct < 45) {
      if (degradedSince == 0) degradedSince = millis();
      else if (millis() - degradedSince > 60000) {
        streamRedials++;
        Serial.printf("STREAM: buffer degraded <45%% for 60s (buf=%u%% rssi=%d) "
                      "-- redialling (#%u)\n",
                      (unsigned)bufPct, WiFi.isConnected() ? WiFi.RSSI() : 0,
                      (unsigned)streamRedials);
        startPlayback();
        lowBufSince   = 0;
        degradedSince = 0;
      }
    } else {
      degradedSince = 0;   // recovered above 45%, reset the slow timer
    }
  } else {
    lowBufSince   = 0;
    degradedSince = 0;
  }

  // Telemetry is gated behind the hidden overlay (Ctrl+D), so a release build
  // is silent in normal use but fully instrumented the moment you need it.
  // Unattended soak log: fires even when the screen is blanked, and reports
  // per-interval worst cases so a failure is timestamped, not just a watermark.
  if (soakLog && isPlaying && millis() - lastBufLog > 5000) {
    lastBufLog = millis();
    uint32_t secs = millis() / 1000;
    const char* verdict =
        (bufIntervalMin < 20) ? "STARVED-net"   :   // buffer genuinely draining
        (gapIntervalMax > 80) ? "STARVED-cpu"   :   // decoder/output hitching
                                "ok";
    Serial.printf("[%02u:%02u:%02u] %s buf<=%u%% gap<=%ums under=%u "
                  "heap=%u big=%u rssi=%d rdl=%u\n",
                  (unsigned)(secs / 3600), (unsigned)((secs % 3600) / 60),
                  (unsigned)(secs % 60), verdict,
                  (unsigned)bufIntervalMin, (unsigned)(gapIntervalMax / 1000),
                  (unsigned)underrunEvents,
                  (unsigned)ESP.getFreeHeap(),
                  (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_8BIT),
                  WiFi.isConnected() ? WiFi.RSSI() : 0,
                  (unsigned)streamRedials);
    gapIntervalMax = 0;
    bufIntervalMin = 100;
    underrunEvents = 0;
  }

  if (showDiag && millis() - lastBufLog > 2000) {
    lastBufLog = millis();
    // 'big' = largest contiguous free block. Free heap can stay flat while
    // this shrinks -- that IS fragmentation, and it's what makes a later
    // allocation fail even though there is "plenty of heap".
    // Watch big/heap over a long run: heap flat + big falling = fragmenting.
    uint32_t big = heap_caps_get_largest_free_block(MALLOC_CAP_8BIT);
    Serial.printf("up=%lus %s%s buf=%3u%% lows=%u gap=%ums dec=%ums drw=%ums "
                  "heap=%u big=%u min=%u rssi=%d\n",
                  (unsigned long)(millis() / 1000),
                  isPlaying ? "PLAY" : "stop",
                  recActive ? "+REC" : "    ",
                  (unsigned)bufPct, (unsigned)bufLowCount,
                  (unsigned)(gapMaxUs / 1000), (unsigned)(decMaxUs / 1000),
                  (unsigned)(drwMaxUs / 1000),
                  (unsigned)ESP.getFreeHeap(),
                  (unsigned)big,
                  (unsigned)ESP.getMinFreeHeap(),
                  WiFi.isConnected() ? WiFi.RSSI() : 0);
  }

  bool marqueeRunning = isPlaying && streamTitleLen > 31;
  uint32_t interval = marqueeRunning ? UI_REFRESH_MS : UI_IDLE_MS;

  if (brightness > 0 && millis() - lastDraw > interval) {
    if (marqueeRunning) marqueeOffset++;
    uint32_t t0 = micros();
    drawUI();
    uint32_t drw = micros() - t0;
    if (drw > drwMaxUs) drwMaxUs = drw;
  }

  // Do NOT busy-spin. Without this the loop task hammers the I2C keyboard
  // and never yields, which starves the idle task and adds scheduling
  // latency for everything else on this core.
  delay(2);
}

// ============================================================
//  SCREEN DIMMING
// ============================================================
void wakeScreen() {
  lastActivity = millis();
  if (brightness != BRIGHT_FULL) {
    brightness = BRIGHT_FULL;
    disp.setBrightness(brightness);
  }
}

void updateDimming() {
  uint32_t idle = millis() - lastActivity;
  uint8_t target = BRIGHT_FULL;

  if      (idle > OFF_TIMEOUT_MS) target = 0;
  else if (idle > DIM_TIMEOUT_MS) target = BRIGHT_DIM;

  // While recording, dim but never fully blank: the REC indicator stays
  // visible and the wake-up press has visible feedback.
  if (recActive && target == 0) target = BRIGHT_DIM;

  if (target != brightness) {
    brightness = target;
    disp.setBrightness(brightness);
  }
}

// ============================================================
//  AUDIO TASK  (core 1, priority above the Arduino loop)
// ============================================================
void audioTask(void* arg) {
  uint32_t lastRun = micros();

  for (;;) {
    // How long since this task last got the CPU? A big number here means
    // something else on this core is hogging it.
    uint32_t now = micros();
    uint32_t gap = now - lastRun;
    if (isPlaying && gap > gapMaxUs) gapMaxUs = gap;
    if (isPlaying && gap > gapIntervalMax) gapIntervalMax = gap;
    lastRun = now;

    if (xSemaphoreTake(audioMutex, portMAX_DELAY) == pdTRUE) {
      uint32_t t0 = micros();
      audio.loop();
      uint32_t dec = micros() - t0;
      if (isPlaying && dec > decMaxUs) decMaxUs = dec;

      if (isPlaying) {
        uint32_t filled = audio.inBufferFilled();
        uint32_t total  = filled + audio.inBufferFree();
        if (total > 0) {
          uint32_t prev = bufPct;
          bufPct = (filled * 100) / total;
          if (bufPct < 10) bufLowCount++;
          if (bufPct < bufIntervalMin) bufIntervalMin = bufPct;
          if (bufPct < 25 && prev >= 25) underrunEvents++;
        }
      }
      xSemaphoreGive(audioMutex);
    }
    vTaskDelay(1);
  }
}

// ============================================================
//  UI  -- drawn directly to the display. No sprite: that 32KB is
//  the audio buffer now. Flicker is avoided by painting text with
//  an opaque background and padding fields to a fixed width.
// ============================================================
void drawUI() {
  lastDraw = millis();

  // Hold the SPI bus for the whole frame.
  //
  // startWrite/endWrite matter as much as the mutex: M5GFX pushes pixels via
  // DMA and its draw calls RETURN BEFORE THE TRANSFER COMPLETES. Releasing the
  // mutex at the end of the frame therefore handed the bus to the SD card
  // while display DMA was still in flight -- so the two collided anyway and
  // f.write() came back short (fail code -108). endWrite() blocks until the
  // DMA has actually drained.
  SPI_LOCK();
  disp.startWrite();

  currentScreen = pickerOpen ? SCR_PICKER : SCR_MAIN;
  if (currentScreen != lastScreen) {
    disp.fillScreen(C_BG);
    if (currentScreen == SCR_MAIN) drawMainChrome();
    lastScreen = currentScreen;
  }

  if (pickerOpen) drawPicker();
  else            drawMain();

  disp.endWrite();     // wait for DMA to drain BEFORE letting SD have the bus
  disp.waitDMA();
  SPI_UNLOCK();
}

// Static parts of the main screen: drawn once on entry, not every frame.
void drawMainChrome() {
  disp.fillRect(0, 0, 240, 16, C_DGREEN);
  disp.setTextSize(1);
  disp.setTextColor(C_BG, C_DGREEN);
  disp.setCursor(5, 4);
  disp.print("CARDPUTER RADIO");
  // Revision lives on the splash screen only -- the title bar is prime real
  // estate and the clock earns it more.

  disp.drawFastHLine(0, 70, 240, C_DGREEN);

  disp.fillRect(0, 119, 240, 16, C_DGREEN);
  disp.setTextColor(C_BG, C_DGREEN);
  disp.setCursor(4, 123);
  disp.print("SPC play N/P stn L list S rec W wifi");
}

void drawMain() {
  disp.setTextSize(1);
  drawClock(172, 4);      // right-aligned, just left of the battery
  drawBattery(178, 3);

  char buf[64];

  if (stations.size() == 0) {
    disp.setTextColor(C_RED, C_BG);
    printPad(6, 40, "No stations loaded", 34);
    return;
  }

  // Station name, ALWAYS at text size 2, wrapped across two lines.
  //
  // The old code dropped to the small font past 19 chars, which caught most of
  // the station list. Worse, the two layouts painted different regions: size-2
  // text is 16px tall (y=20..35) while the small font drew 8px lines, leaving
  // an unpainted 2px band of leftover pixels from the previous large glyphs --
  // the row of "dots" under the name.
  //
  // Both lines are now printPad'd to a fixed width at fixed positions, so the
  // whole name block (y=20..51) is repainted every frame. No ghosts possible.
  char l1[24], l2[24];
  wrapName(stations[currentStation].name.c_str(), l1, sizeof(l1), l2, sizeof(l2));

  disp.setTextColor(C_GREEN, C_BG);
  disp.setTextSize(2);
  printPad(6, 20, l1, 19);     // covers y=20..35
  printPad(6, 36, l2, 19);     // covers y=36..51  (blank line clears itself)
  disp.setTextSize(1);

  // Status line, in priority order. The old version showed "buffering..."
  // whenever there was no ICY title -- but plenty of stations never send one,
  // so it lied for as long as you listened. Every branch below is true.
  disp.setTextSize(1);
  disp.setTextColor(C_GREY, C_BG);

  // station counter, right-aligned on the status line
  snprintf(buf, sizeof(buf), "%d/%d", currentStation + 1, (int)stations.size());
  disp.setTextColor(C_GREY, C_BG);
  disp.fillRect(196, 54, 40, 9, C_BG);
  disp.setCursor(234 - (strlen(buf) * 6), 54);
  disp.print(buf);

  disp.setTextColor(C_GREY, C_BG);
  if (!isPlaying) {
    printPad(6, 54, "", 31);
  } else if (bufPct < 20) {
    // genuinely still filling the buffer -- show how far along
    char b[40];
    uint32_t br = audio.getBitRate();
    if (br == 0) snprintf(b, sizeof(b), "connecting...");
    else         snprintf(b, sizeof(b), "buffering %u%%", (unsigned)bufPct);
    printPad(6, 54, b, 31);
  } else if (streamTitleLen > 0) {
    if (streamTitleLen > 31) {
      static const char SEP[] = "   ///   ";
      const int sepLen = sizeof(SEP) - 1;
      int total = streamTitleLen + sepLen;
      int pos   = marqueeOffset % total;

      char view[32];
      for (int i = 0; i < 31; i++) {
        int idx = (pos + i) % total;
        view[i] = (idx < streamTitleLen) ? streamTitle[idx] : SEP[idx - streamTitleLen];
      }
      view[31] = '\0';
      printPad(6, 54, view, 31);
    } else {
      printPad(6, 54, streamTitle, 31);
    }
  } else if (icyStation[0]) {
    printPad(6, 54, icyStation, 31);          // station's own name
  } else if (icyDesc[0]) {
    printPad(6, 54, icyDesc, 31);
  } else {
    // No metadata at all. Say what we're actually decoding -- far more useful
    // than a permanent lie about buffering.
    char fmt[48];
    uint32_t br = audio.getBitRate();
    uint32_t sr = audio.getSampleRate();
    if (br > 0 && sr > 0) {
      snprintf(fmt, sizeof(fmt), "%s %ukbps %u.%ukHz %s",
               audio.getCodecname(),
               (unsigned)(br / 1000),
               (unsigned)(sr / 1000), (unsigned)((sr % 1000) / 100),
               audio.getChannels() == 2 ? "stereo" : "mono");
    } else {
      snprintf(fmt, sizeof(fmt), "playing");
    }
    printPad(6, 54, fmt, 31);
  }

  // status row
  disp.fillRect(6, 76, 12, 12, C_BG);
  if (isPlaying) {
    disp.fillTriangle(7, 77, 7, 87, 15, 82, C_GREEN);
    disp.setTextColor(C_GREEN, C_BG);
    printPad(21, 79, "PLAYING", 8);
  } else {
    disp.fillRect(7, 77, 3, 10, C_GREY);
    disp.fillRect(12, 77, 3, 10, C_GREY);
    disp.setTextColor(C_GREY, C_BG);
    printPad(21, 79, "STOPPED", 8);
  }

  // recording indicator
  disp.fillRect(76, 76, 128, 12, C_BG);
  if (recActive && recStopReq) {
    disp.setTextColor(C_AMBER, C_BG);
    disp.setCursor(110, 79);
    disp.print("SAVING...");
  } else if (recActive) {
    uint32_t secs = (millis() - recStartMs) / 1000;
    if ((millis() / 600) % 2) disp.fillCircle(112, 82, 4, C_RED);
    disp.setTextColor(C_RED, C_BG);
    disp.setCursor(120, 79);
    if (recReconnects > 0)
      disp.printf("REC %02u:%02u r%u", (unsigned)(secs / 60), (unsigned)(secs % 60),
                  (unsigned)recReconnects);
    else
      disp.printf("REC %02u:%02u", (unsigned)(secs / 60), (unsigned)(secs % 60));
  } else if (recFailMs && millis() - recFailMs < 3000) {
    disp.setTextColor(C_RED, C_BG);
    disp.setCursor(104, 79);
    disp.printf("REC FAIL %d", recFailCode);
  }

  drawWifiBars(210, 77);

  // volume, or diagnostics in its place
  if (showDiag) {
    disp.setTextSize(1);
    disp.setTextColor(C_GREY, C_BG);
    disp.setCursor(4, 92);
    disp.print("BUF");

    uint16_t bc = (bufPct < 25) ? C_RED : (bufPct < 60 ? C_AMBER : C_GREEN);
    disp.drawRect(30, 91, 102, 9, C_DGREEN);
    disp.fillRect(31, 92, 100, 7, C_BG);
    disp.fillRect(31, 92, bufPct, 7, bc);

    disp.setTextColor(bc, C_BG);
    disp.setCursor(138, 92);
    disp.printf("%3u%%", (unsigned)bufPct);

    char up[16];
    formatUptime(up, sizeof(up));
    disp.setTextColor(soakLog ? C_GREEN : C_GREY, C_BG);
    printPad(174, 92, soakLog ? "LOG" : up, 10);

    uint32_t gapMs = gapMaxUs / 1000;
    disp.setTextColor(gapMs > 50 ? C_RED : (gapMs > 20 ? C_AMBER : C_GREY), C_BG);
    snprintf(buf, sizeof(buf), "gap:%ums dec:%u drw:%u rdl:%u",
             (unsigned)gapMs, (unsigned)(decMaxUs / 1000),
             (unsigned)(drwMaxUs / 1000), (unsigned)streamRedials);
    printPad(4, 106, buf, 38);

    // 'big' is the number that matters: free heap can look fine while the
    // largest contiguous block collapses. That IS fragmentation.
    uint32_t bigK = heap_caps_get_largest_free_block(MALLOC_CAP_8BIT) / 1024;
    uint32_t minK = ESP.getMinFreeHeap() / 1024;
    disp.setTextColor((bigK < 20 || minK < 20) ? C_RED : C_GREY, C_BG);
    snprintf(buf, sizeof(buf), "heap:%uk big:%uk min:%uk",
             (unsigned)(ESP.getFreeHeap() / 1024), (unsigned)bigK, (unsigned)minK);
    printPad(4, 114, buf, 38);
  } else {
    drawVolumeBar(6, 98);
  }
}

// Clock, right-aligned to rightX. Uses time() directly rather than
// getLocalTime(), which can block waiting for a sync -- not something we want
// on a path that runs every frame.
void drawClock(int rightX, int y) {
  char buf[16];
  time_t now = time(nullptr);

  if (now > 1600000000) {          // sane => NTP has landed
    struct tm t;
    localtime_r(&now, &t);
    int h12 = t.tm_hour % 12;
    if (h12 == 0) h12 = 12;
    snprintf(buf, sizeof(buf), "%d:%02d %s",
             h12, t.tm_min, t.tm_hour < 12 ? "AM" : "PM");
  } else {
    snprintf(buf, sizeof(buf), "--:--");
  }

  int w = strlen(buf) * 6;
  disp.setTextSize(1);
  disp.fillRect(rightX - 52, y - 1, 52, 10, C_DGREEN);   // clear old time
  disp.setTextColor(C_BG, C_DGREEN);
  disp.setCursor(rightX - w, y);
  disp.print(buf);
}

// Uptime, compactly: "7m", "2h05m", "3d4h".
// Note millis() wraps at ~49.7 days; this will read oddly after that.
static void formatUptime(char* out, size_t n) {
  uint32_t secs = millis() / 1000;
  uint32_t d = secs / 86400;
  uint32_t h = (secs % 86400) / 3600;
  uint32_t m = (secs % 3600) / 60;

  if      (d > 0) snprintf(out, n, "%ud%uh",  (unsigned)d, (unsigned)h);
  else if (h > 0) snprintf(out, n, "%uh%02um", (unsigned)h, (unsigned)m);
  else            snprintf(out, n, "%um",      (unsigned)m);
}

// Returns a stable battery percentage. Sampled at most once a second, run
// through an exponential moving average, and held via hysteresis so it only
// changes when the underlying level really has.
static int smoothedBatteryLevel() {
  if (millis() - lastBattMs > 1000 || battAvg < 0.0f) {
    lastBattMs = millis();

    int raw = M5Cardputer.Power.getBatteryLevel();
    if (raw < 0)   raw = 0;
    if (raw > 100) raw = 100;

    if (battAvg < 0.0f) {
      battAvg   = raw;        // seed on first read, no ramp-up from zero
      battShown = raw;
    } else {
      // EMA, alpha = 0.1 -> ~30s to settle at 1 sample/sec. Slow on purpose:
      // battery level has no business changing quickly.
      battAvg = (battAvg * 0.9f) + (raw * 0.1f);
    }

    // Hysteresis: only move the displayed value once the average has drifted
    // more than 1.5 points away from it. Prevents 1-point oscillation when
    // the true level sits on a boundary.
    if (battAvg > battShown + 1.5f)      battShown++;
    else if (battAvg < battShown - 1.5f) battShown--;

    if (battShown < 0)   battShown = 0;
    if (battShown > 100) battShown = 100;
  }
  return battShown;
}

void drawBattery(int x, int y) {
  int level = smoothedBatteryLevel();

  bool charging = (M5Cardputer.Power.isCharging() == m5::Power_Class::is_charging);

  char pct[8];
  snprintf(pct, sizeof(pct), "%d%%", level);
  disp.setTextSize(1);
  disp.setTextColor(C_BG, C_DGREEN);
  disp.fillRect(x, y, 30, 10, C_DGREEN);
  disp.setCursor(x + 28 - (strlen(pct) * 6), y + 1);
  disp.print(pct);

  int bx = x + 32;
  disp.fillRect(bx, y, 24, 10, C_DGREEN);
  disp.drawRect(bx, y, 22, 10, C_BG);
  disp.fillRect(bx + 22, y + 3, 2, 4, C_BG);

  uint16_t fill = C_GREEN;
  if (level <= 20)      fill = C_RED;
  else if (level <= 40) fill = C_AMBER;

  int w = (level * 18) / 100;
  if (w > 0) disp.fillRect(bx + 2, y + 2, w, 6, fill);

  if (charging) {
    disp.fillTriangle(bx + 12, y + 1, bx + 7,  y + 6, bx + 12, y + 6, C_BG);
    disp.fillTriangle(bx + 11, y + 9, bx + 16, y + 4, bx + 11, y + 4, C_BG);
  }
}

void drawVolumeBar(int x, int y) {
  disp.setTextSize(1);
  disp.setTextColor(C_GREY, C_BG);
  disp.setCursor(x, y + 1);
  disp.print("VOL");

  int bx = x + 26;
  for (int i = 0; i < 21; i++) {
    int sx = bx + (i * 8);
    if (i < volume) disp.fillRect(sx, y - 1, 6, 11, C_GREEN);
    else {
      disp.fillRect(sx, y - 1, 6, 11, C_BG);
      disp.drawRect(sx, y - 1, 6, 11, C_DGREEN);
    }
  }

  char v[8];
  snprintf(v, sizeof(v), "%2d", volume);
  disp.setTextColor(C_GREEN, C_BG);
  disp.setCursor(220, y + 1);
  disp.print(v);
}

void drawWifiBars(int x, int y) {
  int rssi = WiFi.isConnected() ? WiFi.RSSI() : -100;
  int bars = 0;
  if      (rssi > -55) bars = 4;
  else if (rssi > -66) bars = 3;
  else if (rssi > -75) bars = 2;
  else if (rssi > -85) bars = 1;

  for (int i = 0; i < 4; i++) {
    int h  = 3 + (i * 3);
    int bx = x + (i * 6);
    int by = y + 12 - h;
    disp.fillRect(bx, by, 4, h, (i < bars) ? C_GREEN : C_DGREEN);
  }
}

// ============================================================
//  STATION PICKER
// ============================================================
void openPicker() {
  pickerOpen = true;
  pickerSel  = currentStation;
  pickerTop  = pickerSel - (PICKER_ROWS / 2);
  if (pickerTop > (int)stations.size() - PICKER_ROWS) pickerTop = stations.size() - PICKER_ROWS;
  if (pickerTop < 0) pickerTop = 0;
}

void handlePickerKeys(Keyboard_Class::KeysState& status) {
  if (status.enter) {
    pickerOpen = false;
    currentStation = pickerSel;
    saveSettingsDebounced();
    startPlayback();
    return;
  }

  for (char c : status.word) {
    // ';' and '.' are the arrow-labelled keys
    if (c == ';') {
      if (pickerSel > 0) pickerSel--;
    } else if (c == '.') {
      if (pickerSel < (int)stations.size() - 1) pickerSel++;
    } else if (c == '`' || c == 'l' || c == 'L') {
      pickerOpen = false;
      return;
    }
  }

  if (pickerSel < pickerTop)                pickerTop = pickerSel;
  if (pickerSel >= pickerTop + PICKER_ROWS) pickerTop = pickerSel - PICKER_ROWS + 1;
}

void drawPicker() {
  disp.fillRect(0, 0, 240, 16, C_DGREEN);
  disp.setTextSize(1);
  disp.setTextColor(C_BG, C_DGREEN);
  disp.setCursor(5, 4);
  disp.printf("STATIONS (%d)", (int)stations.size());
  drawBattery(178, 3);

  int y = 20;
  for (int i = pickerTop; i < pickerTop + PICKER_ROWS; i++) {
    if (i >= (int)stations.size()) {
      disp.fillRect(0, y - 2, 240, 13, C_BG);
      y += 13;
      continue;
    }

    bool sel = (i == pickerSel);
    if (sel) {
      disp.fillRect(0, y - 2, 234, 13, C_GREEN);
      disp.setTextColor(C_BG, C_GREEN);
    } else {
      disp.fillRect(0, y - 2, 234, 13, C_BG);
      disp.setTextColor((i == currentStation) ? C_GREEN : C_GREY, C_BG);
    }

    char row[42];
    snprintf(row, sizeof(row), "%s%.36s",
             (i == currentStation) ? "> " : "  ",
             stations[i].name.c_str());
    disp.setCursor(4, y);
    disp.print(row);

    y += 13;
  }

  // scrollbar
  int trackY = 18, trackH = 98;
  disp.fillRect(236, trackY, 3, trackH, C_DGREEN);
  if ((int)stations.size() > PICKER_ROWS) {
    int barH = max(8, trackH * PICKER_ROWS / (int)stations.size());
    int barY = trackY + (trackH - barH) * pickerTop /
               max(1, (int)stations.size() - PICKER_ROWS);
    disp.fillRect(236, barY, 3, barH, C_GREEN);
  }

  disp.fillRect(0, 119, 240, 16, C_DGREEN);
  disp.setTextColor(C_BG, C_DGREEN);
  disp.setCursor(4, 123);
  disp.print("; up  . down  ENTER tune  L back");
}

// ============================================================
//  STATIONS
// ============================================================
void loadStationsFromSD() {
  if (!SD.exists("/station_list.txt")) {
    Serial.println("station_list.txt not found on SD");
    return;
  }

  File file = SD.open("/station_list.txt", FILE_READ);
  if (!file) return;

  stations.clear();
  while (file.available()) {
    String line = file.readStringUntil('\n');
    line.trim();
    if (line.length() == 0 || line.startsWith("#")) continue;

    int comma = line.indexOf(',');
    if (comma > 0) {
      Station s;
      s.name = line.substring(0, comma);
      s.url  = line.substring(comma + 1);
      s.name.trim();
      s.url.trim();
      stations.push_back(s);
    }
  }
  file.close();
}

void loadDefaultStations() {
  stations.clear();
  for (int i = 0; i < numDefaultStations; i++) stations.push_back(defaultStations[i]);
  Serial.printf("Loaded %d built-in stations\n", numDefaultStations);
}

// ============================================================
//  PLAYBACK
// ============================================================
void togglePlayPause() {
  if (isPlaying) stopPlayback();
  else           startPlayback();
}

void startPlayback() {
  if (stations.size() == 0) return;
  streamTitle[0] = '\0';
  streamTitleLen = 0;
  icyStation[0]  = '\0';
  icyDesc[0]     = '\0';
  marqueeOffset  = 0;

  xSemaphoreTake(audioMutex, portMAX_DELAY);
  audio.stopSong();
  audio.connecttohost(stations[currentStation].url.c_str());
  xSemaphoreGive(audioMutex);

  isPlaying  = true;
  lastDialMs = millis();
  saveSettingsDebounced();   // remember we were playing, for auto-resume   // starts the watchdog grace window

  // Ask for a DEFERRED reset of the timing watermarks (see loop()).
  //
  // connecttohost() blocks on purpose -- DNS, a TLS handshake (~1.2s), and
  // decoder init -- while this function holds audioMutex, so the audio task is
  // stalled throughout. As a high-water mark that would pin gap at ~2s for the
  // rest of the session and mask every real stall afterwards.
  //
  // Resetting HERE does not work: the audio task is priority 10 and preempts
  // the instant we release the mutex, so the spike is recorded a few hundred
  // microseconds AFTER this line runs. Defer instead.
  metricsPending = true;
  streamRateSeen = 0;      // re-arm the stream format guard
  formatChanged  = false;
}

void stopPlayback() {
  xSemaphoreTake(audioMutex, portMAX_DELAY);
  audio.stopSong();
  xSemaphoreGive(audioMutex);

  streamTitle[0] = '\0';
  streamTitleLen = 0;
  icyStation[0]  = '\0';
  icyDesc[0]     = '\0';
  isPlaying      = false;
  bufPct         = 0;
}

void nextStation() {
  if (stations.size() == 0) return;
  currentStation = (currentStation + 1) % stations.size();
  saveSettingsDebounced();
  if (isPlaying) startPlayback();
}

void previousStation() {
  if (stations.size() == 0) return;
  currentStation = (currentStation - 1 + stations.size()) % stations.size();
  saveSettingsDebounced();
  if (isPlaying) startPlayback();
}

void increaseVolume() {
  if (volume < 21) {
    volume++;
    xSemaphoreTake(audioMutex, portMAX_DELAY);
    audio.setVolume(volume);
    xSemaphoreGive(audioMutex);
    saveSettingsDebounced();
  }
}

void decreaseVolume() {
  if (volume > 0) {
    volume--;
    xSemaphoreTake(audioMutex, portMAX_DELAY);
    audio.setVolume(volume);
    xSemaphoreGive(audioMutex);
    saveSettingsDebounced();
  }
}

// ============================================================
//  STREAM RECORDER
//  Second HTTP connection to the same stream, teeing the raw
//  compressed bytes to SD on core 0.
//
//  Filenames carry start AND end time:
//    /rec/WGUC909Class_0712_1430-1512.mp3
// ============================================================
static String sanitizeName(const String& in) {
  String out = "";
  for (unsigned int i = 0; i < in.length() && out.length() < 12; i++) {
    char c = in[i];
    if (isalnum(c)) out += c;
  }
  return out.length() ? out : String("station");
}

static String hhmm(const struct tm& t) {
  char b[8];
  snprintf(b, sizeof(b), "%02d%02d", t.tm_hour, t.tm_min);
  return String(b);
}

static String mmdd(const struct tm& t) {
  char b[8];
  snprintf(b, sizeof(b), "%02d%02d", t.tm_mon + 1, t.tm_mday);
  return String(b);
}

void startRecording() {
  if (recActive || stations.size() == 0) return;

  // Don't start a recording we can't afford: a failed allocation mid-stream
  // is worse than a refusal up front.
  // Check the largest contiguous block, not total free: the recorder needs an
  // 8KB task stack in ONE piece. 30KB of fragmented heap cannot supply it.
  uint32_t big = heap_caps_get_largest_free_block(MALLOC_CAP_8BIT);
  if (big < 10000) {
    Serial.printf("REC refused: largest free block only %u bytes\n", (unsigned)big);
    recFailCode = -106;
    recFailMs   = millis();
    return;
  }

  SPI_LOCK();
  SD.mkdir("/rec");
  SPI_UNLOCK();

  recTimeValid = getLocalTime(&recStartTm, 250);
  String name = sanitizeName(stations[currentStation].name);

  if (recTimeValid) {
    recBase = "/rec/" + name + "_" + mmdd(recStartTm) + "_" + hhmm(recStartTm);
  } else {
    recBase = "/rec/" + name + "_up" + String(millis() / 1000);
  }

  // Force plain HTTP for the recording connection.
  //
  // A TLS handshake needs ~40KB of free heap. With no PSRAM we never have
  // that, so every https attempt allocated a large mbedTLS context, failed,
  // and fell back to http anyway -- paying the full memory spike for a
  // guaranteed failure. That spike is what drove min-heap to ~12k.
  // These radio servers all serve the same stream unencrypted.
  recUrl = stations[currentStation].url;
  if (recUrl.startsWith("https://")) recUrl = "http://" + recUrl.substring(8);

  recBytes      = 0;
  recReconnects = 0;
  sdRecoveries  = 0;
  recStopReq    = false;
  recStartMs = millis();
  recActive  = true;

  // 6KB stack. No mbedTLS in this task any more, so it needs far less; the
  // "stack headroom" figure in the REC done line tells us if this is too tight.
  xTaskCreatePinnedToCore(recorderTask, "recorder", 6144, NULL, 1, &recTaskHandle, 0);
  Serial.printf("REC start: %s (heap %u)\n", recBase.c_str(), (unsigned)ESP.getFreeHeap());
}

void requestStopRecording() {
  recStopReq = true;
  Serial.println("REC stop requested BY USER ('S' key handler)");
}

struct UrlParts {
  bool     tls;
  String   host;
  uint16_t port;
  String   path;
};

static bool parseUrl(const String& url, UrlParts& p) {
  int schemeEnd = url.indexOf("://");
  if (schemeEnd < 0) return false;

  String scheme = url.substring(0, schemeEnd);
  p.tls  = (scheme == "https");
  p.port = p.tls ? 443 : 80;

  int hostStart = schemeEnd + 3;
  int pathStart = url.indexOf('/', hostStart);
  String hostPort = (pathStart < 0) ? url.substring(hostStart)
                                    : url.substring(hostStart, pathStart);
  p.path = (pathStart < 0) ? "/" : url.substring(pathStart);

  int colon = hostPort.indexOf(':');
  if (colon >= 0) {
    p.host = hostPort.substring(0, colon);
    p.port = hostPort.substring(colon + 1).toInt();
  } else {
    p.host = hostPort;
  }
  return p.host.length() > 0;
}

static String readHttpLine(WiFiClient* c) {
  String line = c->readStringUntil('\n');
  line.trim();
  return line;
}

// Connect and consume headers, following redirects. Returns true when the
// socket is positioned at the first byte of audio.
static bool recConnect(WiFiClient& c, String url, String& contentType, int& failCode) {
  for (int hop = 0; hop < 5; hop++) {
    UrlParts u;
    if (!parseUrl(url, u)) { failCode = -100; return false; }

    // We cannot afford TLS (see startRecording); pull https back to http.
    if (u.tls) { u.tls = false; u.port = 80; }

    IPAddress ip;
    if (!WiFi.hostByName(u.host.c_str(), ip)) { failCode = -104; return false; }

    c.setTimeout(3000);
    Serial.printf("REC connect %s:%u heap=%u\n",
                  u.host.c_str(), u.port, (unsigned)ESP.getFreeHeap());

    if (!c.connect(ip, u.port, 8000)) { failCode = -101; return false; }

    c.printf("GET %s HTTP/1.0\r\n"
             "Host: %s\r\n"
             "User-Agent: CardputerRadio/1.0\r\n"
             "Accept: */*\r\n"
             "Connection: close\r\n\r\n",
             u.path.c_str(), u.host.c_str());

    String status = readHttpLine(&c);
    Serial.println("REC status: " + status);
    int sp = status.indexOf(' ');
    int code = (sp > 0) ? status.substring(sp + 1).toInt() : 0;

    String location = "";
    contentType = "";
    while (true) {
      String h = readHttpLine(&c);
      if (h.length() == 0) break;
      String hl = h;
      hl.toLowerCase();
      if (hl.startsWith("location:"))     { location    = h.substring(9);  location.trim(); }
      if (hl.startsWith("content-type:")) { contentType = h.substring(13); contentType.trim(); }
    }

    if (code == 200) return true;

    if ((code == 301 || code == 302 || code == 303 || code == 307 || code == 308)
        && location.length() > 0) {
      c.stop();
      url = location.startsWith("/")
              ? String("http://") + u.host + ":" + u.port + location
              : location;
      Serial.println("REC redirect -> " + url);
      continue;
    }

    failCode = code ? code : -102;
    return false;
  }
  failCode = -107;   // too many redirects
  return false;
}

void recorderTask(void* arg) {
  // Plain WiFiClient only -- a WiFiClientSecure would allocate a ~40KB
  // mbedTLS context we cannot afford. See startRecording().
  WiFiClient c;
  String     contentType = "";
  int        failCode = 0;

  if (!recConnect(c, recUrl, contentType, failCode)) {
    recFailCode = failCode;
    recFailMs   = millis();
    Serial.printf("REC failed to start, code %d\n", failCode);
    recActive     = false;
    recTaskHandle = NULL;
    vTaskDelete(NULL);
    return;
  }

  String ext = ".mp3";
  contentType.toLowerCase();
  if (contentType.indexOf("aac") >= 0)      ext = ".aac";
  else if (contentType.indexOf("ogg") >= 0) ext = ".ogg";

  String tmpPath = recBase + "_rec" + ext;
  SPI_LOCK();
  File f = SD.open(tmpPath, FILE_WRITE);
  SPI_UNLOCK();
  uint8_t* buf = (uint8_t*)malloc(2048);

  if (!f || !buf) {
    if (f) f.close();
    if (buf) free(buf);
    c.stop();
    recFailCode = f ? -105 : -103;
    recFailMs   = millis();
    recActive     = false;
    recTaskHandle = NULL;
    vTaskDelete(NULL);
    return;
  }

  uint32_t lastFlush = 0;
  bool     sdFailed  = false;

  // Outer loop: a dropped connection must NOT end the recording. Icecast and
  // Shoutcast servers routinely disconnect clients, and a 2-hour capture has
  // no business dying because a socket closed at minute four. Reconnect and
  // keep appending to the SAME file.
  while (!recStopReq && !sdFailed) {
    uint32_t lastData = millis();

    // --- stream until something interrupts us ---
    while (!recStopReq) {
      if (!c.connected() && !c.available()) {
        Serial.printf("REC EXIT: server closed connection (%u bytes so far)\n",
                      (unsigned)recBytes);
        break;
      }

      size_t avail = c.available();
      if (avail) {
        size_t want = avail < 2048 ? avail : 2048;
        int    n    = c.read(buf, want);
        if (n > 0) {
          SPI_LOCK();
          size_t wrote = f.write(buf, n);
          SPI_UNLOCK();

          if (wrote != (size_t)n) {
            Serial.printf("REC short write (%u/%d), err=%d -- recovering\n",
                          (unsigned)wrote, n, f.getWriteError());

            // Recover rather than abandon the recording: flush, close, reopen
            // in append mode, and write the remainder. Only give up after
            // several consecutive failures.
            bool recovered = false;
            for (int attempt = 0; attempt < 3 && !recovered; attempt++) {
              vTaskDelay(pdMS_TO_TICKS(100));

              SPI_LOCK();
              f.flush();
              f.close();
              f = SD.open(tmpPath, FILE_APPEND);
              size_t again = f ? f.write(buf + wrote, n - wrote) : 0;
              SPI_UNLOCK();

              if (f && again == (size_t)(n - wrote)) {
                recovered = true;
                sdRecoveries++;
                Serial.printf("REC recovered SD write (#%u)\n",
                              (unsigned)sdRecoveries);
              }
            }

            if (!recovered) {
              Serial.println("REC EXIT: SD write failed after 3 recovery attempts");
              sdFailed = true;
              break;
            }
          }
          recBytes += n;
          lastData = millis();
        }
      } else {
        if (millis() - lastData > 15000) {
          Serial.printf("REC EXIT: stalled, no data for 15s (%u bytes so far)\n",
                        (unsigned)recBytes);
          break;
        }
        vTaskDelay(pdMS_TO_TICKS(20));
      }

      if (recBytes - lastFlush > 65536) {
        SPI_LOCK();
        f.flush();                 // cap data loss on power cut to a few seconds
        SPI_UNLOCK();
        lastFlush = recBytes;
      }
    }

    if (recStopReq || sdFailed) break;

    // --- reconnect and carry on appending ---
    c.stop();
    SPI_LOCK();
    f.flush();
    SPI_UNLOCK();
    recReconnects++;

    if (recReconnects > REC_MAX_RECONNECTS) {
      Serial.println("REC giving up: too many reconnects");
      break;
    }

    Serial.printf("REC reconnecting (#%u), %u bytes so far\n",
                  (unsigned)recReconnects, (unsigned)recBytes);

    // brief backoff so we don't hammer a server that is refusing us
    for (int i = 0; i < 20 && !recStopReq; i++) vTaskDelay(pdMS_TO_TICKS(100));
    if (recStopReq) break;

    if (!recConnect(c, recUrl, contentType, failCode)) {
      Serial.printf("REC reconnect failed, code %d -- retrying\n", failCode);
      vTaskDelay(pdMS_TO_TICKS(2000));
    }
  }

  SPI_LOCK();
  f.flush();
  f.close();
  SPI_UNLOCK();
  c.stop();
  free(buf);

  // rename with the end time
  struct tm endTm;
  String finalPath;
  if (recTimeValid && getLocalTime(&endTm, 250)) {
    bool sameDay = (endTm.tm_mday == recStartTm.tm_mday &&
                    endTm.tm_mon  == recStartTm.tm_mon);
    finalPath = recBase + "-" + (sameDay ? "" : mmdd(endTm) + "_") + hhmm(endTm) + ext;
  } else {
    finalPath = recBase + "-up" + String(millis() / 1000) + ext;
  }
  SPI_LOCK();
  SD.rename(tmpPath, finalPath);
  SPI_UNLOCK();

  Serial.printf("REC done: %s (%u bytes, %u reconnects, %u SD recoveries), "
                "heap %u, stack headroom %u bytes\n",
                finalPath.c_str(), (unsigned)recBytes,
                (unsigned)recReconnects, (unsigned)sdRecoveries,
                (unsigned)ESP.getFreeHeap(),
                (unsigned)(uxTaskGetStackHighWaterMark(NULL) * 4));

  if (recStopReq) Serial.println("REC EXIT: user stop");
  if (sdFailed)   Serial.println("REC EXIT: SD failure");

  if (sdFailed) {
    recFailCode = -108;
    recFailMs   = millis();
  }

  recActive     = false;
  recTaskHandle = NULL;
  vTaskDelete(NULL);
}

// ============================================================
//  WIFI  -- up to MAX_WIFI networks, connects to whichever
//  saved network is actually in range (strongest first)
// ============================================================
void loadWifiCreds() {
  wifiCreds.clear();
  preferences.begin("wifi", true);
  int count = preferences.getInt("count", 0);
  for (int i = 0; i < count && i < MAX_WIFI; i++) {
    WifiCred c;
    c.ssid = preferences.getString(("ssid" + String(i)).c_str(), "");
    c.pass = preferences.getString(("pass" + String(i)).c_str(), "");
    if (c.ssid.length() > 0) wifiCreds.push_back(c);
  }

  // migrate the r3-era single-network storage
  if (wifiCreds.empty()) {
    String legacySSID = preferences.getString("ssid", "");
    String legacyPass = preferences.getString("password", "");
    if (legacySSID.length() > 0) wifiCreds.push_back({legacySSID, legacyPass});
  }

  preferences.end();
  Serial.printf("Loaded %d saved network(s)\n", (int)wifiCreds.size());
}

void saveWifiCred(const String& ssid, const String& pass) {
  bool updated = false;
  for (auto& c : wifiCreds) {
    if (c.ssid == ssid) { c.pass = pass; updated = true; break; }
  }
  if (!updated) {
    if ((int)wifiCreds.size() >= MAX_WIFI) wifiCreds.erase(wifiCreds.begin());
    wifiCreds.push_back({ssid, pass});
  }

  preferences.begin("wifi", false);
  preferences.putInt("count", (int)wifiCreds.size());
  for (int i = 0; i < (int)wifiCreds.size(); i++) {
    preferences.putString(("ssid" + String(i)).c_str(), wifiCreds[i].ssid);
    preferences.putString(("pass" + String(i)).c_str(), wifiCreds[i].pass);
  }
  preferences.end();
}

bool tryConnect(const String& ssid, const String& pass, int waitSecs) {
  disp.setCursor(6, disp.getCursorY());
  disp.print("Trying ");
  disp.println(ssid);

  WiFi.begin(ssid.c_str(), pass.c_str());
  int attempts = 0;
  disp.setCursor(6, disp.getCursorY());
  while (WiFi.status() != WL_CONNECTED && attempts < waitSecs * 2) {
    delay(500);
    disp.print(".");
    attempts++;
  }
  disp.println();

  if (WiFi.status() == WL_CONNECTED) {
    WiFi.setSleep(false);   // modem sleep causes stream hiccups
    disp.setCursor(6, disp.getCursorY());
    disp.print("Connected  ");
    disp.println(WiFi.localIP());
    delay(1000);
    return true;
  }
  WiFi.disconnect(true);
  delay(100);
  return false;
}

// Interactive credential prompt.
//   cancellable=false : first boot, must connect before returning.
//   cancellable=true  : on-demand ('W'); a blank SSID (just Enter) aborts.
void setupWiFi(bool cancellable) {
  WiFi.mode(WIFI_STA);

  while (true) {
    String ssid = getTextInput(cancellable ? "WiFi name (blank=cancel):"
                                            : "WiFi network name:");
    if (ssid.length() == 0) {
      if (cancellable) return;   // user bailed
      continue;                  // first boot: keep asking
    }
    String pass = getTextInput("Password:", true);

    disp.fillScreen(C_BG);
    disp.setCursor(6, 6);

    if (tryConnect(ssid, pass, 20)) {
      saveWifiCred(ssid, pass);
      return;
    }

    disp.setCursor(6, disp.getCursorY());
    disp.println("Failed - check password");
    delay(1800);
  }
}

// keep the old no-arg signature working (first boot): NOT cancellable, the
// device must have a network before it leaves setup on a virgin config
void setupWiFi() { setupWiFi(false); }


// Persist volume and last station across reboots.
void loadSettings() {
  preferences.begin("radio", true);
  volume = preferences.getUChar("vol", 10);
  int st = preferences.getInt("station", 0);
  wasPlaying = preferences.getBool("playing", false);
  preferences.end();

  if (volume > 21) volume = 21;
  // clamp station to the list we actually loaded (SD list may have changed)
  if (st < 0 || st >= (int)stations.size()) st = 0;
  currentStation = st;
  Serial.printf("Settings: vol=%u station=%d\n", (unsigned)volume, currentStation);
}

void saveSettingsDebounced() {
  settingsDirty   = true;
  settingsDirtyMs = millis();
}

void flushSettings() {
  if (!settingsDirty) return;
  preferences.begin("radio", false);
  preferences.putUChar("vol", volume);
  preferences.putInt("station", currentStation);
  preferences.putBool("playing", isPlaying);
  preferences.end();
  settingsDirty = false;
  Serial.printf("Settings saved: vol=%u station=%d\n",
                (unsigned)volume, currentStation);
}

// Only BLOCK on the setup prompt when there are NO saved networks at all --
// i.e. genuine first boot. If networks are saved but none are reachable right
// now (away from home, a power blip, etc.), boot into the app offline and let
// the background reconnect (see loop) bring WiFi back when it returns. A radio
// that refuses to start because WiFi is absent is a bad appliance.
void connectWiFi() {
  loadWifiCreds();
  WiFi.mode(WIFI_STA);

  if (wifiCreds.empty()) {
    setupWiFi();          // first boot: must prompt
    return;
  }

  disp.fillScreen(C_BG);
  disp.setTextSize(1);
  disp.setTextColor(C_GREEN, C_BG);
  disp.setCursor(6, 6);
  disp.println("WiFi");
  disp.setCursor(6, 20);
  disp.println("Scanning...");

  int found = WiFi.scanNetworks();
  std::vector<std::pair<int, int>> matches;
  for (int i = 0; i < found; i++) {
    String seen = WiFi.SSID(i);
    for (int j = 0; j < (int)wifiCreds.size(); j++) {
      if (wifiCreds[j].ssid == seen) matches.push_back({WiFi.RSSI(i), j});
    }
  }
  std::sort(matches.begin(), matches.end(),
            [](auto& a, auto& b) { return a.first > b.first; });
  WiFi.scanDelete();

  for (auto& m : matches) {
    if (tryConnect(wifiCreds[m.second].ssid, wifiCreds[m.second].pass, 10)) return;
  }
  if (matches.empty()) {
    for (auto& c : wifiCreds) {
      if (tryConnect(c.ssid, c.pass, 6)) return;
    }
  }

  // Saved networks exist but none reachable -> start OFFLINE, don't block.
  disp.fillScreen(C_BG);
  disp.setCursor(6, 6);
  disp.setTextColor(C_AMBER, C_BG);
  disp.println("No saved WiFi in range");
  disp.setCursor(6, 20);
  disp.println("Starting offline...");
  Serial.println("WiFi: no saved network reachable -- starting offline");
  delay(1500);
}

String getTextInput(String prompt, bool mask) {
  String input = "";

  disp.fillScreen(C_BG);
  disp.fillRect(0, 0, 240, 16, C_DGREEN);
  disp.setTextSize(1);
  disp.setTextColor(C_BG, C_DGREEN);
  disp.setCursor(5, 4);
  disp.print("SETUP");

  disp.setTextColor(C_GREY, C_BG);
  disp.setCursor(6, 30);
  disp.print(prompt);

  disp.fillRect(0, 119, 240, 16, C_DGREEN);
  disp.setTextColor(C_BG, C_DGREEN);
  disp.setCursor(4, 123);
  disp.print("ENTER confirm   DEL backspace");

  while (true) {
    M5Cardputer.update();

    disp.setTextColor(C_GREEN, C_BG);
    char shown[48];
    size_t k = 0;
    shown[k++] = '>'; shown[k++] = ' ';
    for (unsigned int i = 0; i < input.length() && k < sizeof(shown) - 2; i++)
      shown[k++] = mask ? '*' : input[i];
    if ((millis() / 400) % 2 && k < sizeof(shown) - 1) shown[k++] = '_';
    shown[k] = '\0';
    printPad(6, 50, shown, 38);

    if (M5Cardputer.Keyboard.isChange() && M5Cardputer.Keyboard.isPressed()) {
      Keyboard_Class::KeysState status = M5Cardputer.Keyboard.keysState();

      if (status.enter) return input;
      if (status.del && input.length() > 0) input.remove(input.length() - 1);
      for (char c : status.word) {
        if (c >= 32 && c <= 126) input += c;
      }
    }

    delay(20);
  }
}
